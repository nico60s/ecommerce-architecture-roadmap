﻿

namespace Ecommerce.Abstractions.Messaging
{
    public interface ICommand { }
    public interface ICommand<TResponse> { }

}
